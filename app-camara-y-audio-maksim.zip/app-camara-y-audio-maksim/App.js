// App.js
import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Modal,
  TextInput,
  Alert,
  Animated,
  FlatList,
  Easing,
} from 'react-native';
import { Audio, Video } from 'expo-av';
import { Camera } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';
import { Ionicons } from '@expo/vector-icons';
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { useIsFocused } from '@react-navigation/native';

const Tab = createMaterialTopTabNavigator();

// Valor correcto para QR en SDK 48
const QR_TYPE = "org.iso.QRCode";

/* ===============================
   CUSTOM TAB BAR CON ICONOS ANIMADOS
================================= */
function MyTabBar({ state, descriptors, navigation, position }) {
  return (
    <View style={styles.customTabBar}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const iconName = route.name === 'Audio' ? 'mic' : 'camera';
        const isFocused = state.index === index;
        const onPress = () => {
          if (!isFocused) {
            navigation.navigate(route.name);
          }
        };
        const inputRange = state.routes.map((_, i) => i);
        const scale = position.interpolate({
          inputRange,
          outputRange: inputRange.map(i => (i === index ? 1.2 : 1)),
        });
        return (
          <TouchableOpacity key={route.key} onPress={onPress} style={styles.tabBarItem}>
            <Animated.View style={{ transform: [{ scale }] }}>
              <Ionicons name={iconName} size={30} color={isFocused ? '#fff' : '#ccc'} />
            </Animated.View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

/* ===============================
   COMPONENTE DE CONTROL DE VOLUMEN
================================= */
function VolumeControl({ volume, onChange }) {
  const levels = [0, 0.25, 0.5, 0.75, 1];
  const currentIndex = levels.findIndex((lev) => Math.abs(lev - volume) < 0.01);
  return (
    <View style={styles.volumeControlContainer}>
      {levels.map((lev, index) => {
        const filled = index <= (currentIndex === -1 ? 0 : currentIndex);
        return (
          <TouchableOpacity
            key={index}
            style={[styles.volumeBar, { backgroundColor: filled ? '#D32F2F' : '#ccc' }]}
            onPress={() => onChange(lev)}
          />
        );
      })}
    </View>
  );
}

/* ===============================
   PANTALLA DE AUDIO
================================= */
function AudioScreen() {
  const [recording, setRecording] = useState(null);
  const [sound, setSound] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudio, setRecordedAudio] = useState(null);
  const [menuVisible, setMenuVisible] = useState(false);
  const [newAudioName, setNewAudioName] = useState('');
  const [isLooping, setIsLooping] = useState(false);
  const [playbackStatus, setPlaybackStatus] = useState(null);
  const [volume, setVolume] = useState(1);

  const pulse = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1.2,
          duration: 500,
          useNativeDriver: true,
          easing: Easing.ease,
        }),
        Animated.timing(pulse, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
          easing: Easing.ease,
        }),
      ])
    ).start();
  }, [pulse]);

  useEffect(() => {
    return () => {
      if (sound) sound.unloadAsync();
    };
  }, [sound]);

  const startRecording = async () => {
    const { status } = await Audio.requestPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permiso denegado', 'No se pudo obtener permiso para grabar audio');
      return;
    }
    await Audio.setAudioModeAsync({
      allowsRecordingIOS: true,
      playsInSilentModeIOS: true,
    });
    const { recording } = await Audio.Recording.createAsync(
      Audio.RECORDING_OPTIONS_PRESET_HIGH_QUALITY
    );
    setRecording(recording);
    setIsRecording(true);
  };

  const stopRecording = async () => {
    setIsRecording(false);
    await recording.stopAndUnloadAsync();
    const uri = recording.getURI();
    setRecordedAudio({ uri, name: 'Audio grabado' });
    setRecording(null);
  };

  const playAudio = async () => {
    if (recordedAudio?.uri) {
      const { sound } = await Audio.Sound.createAsync(
        { uri: recordedAudio.uri },
        { shouldPlay: true, isLooping: isLooping, volume: volume },
        (status) => setPlaybackStatus(status)
      );
      setSound(sound);
      await sound.playAsync();
    }
  };

  const pauseAudio = async () => {
    if (sound) await sound.pauseAsync();
  };

  const rewindAudio = async () => {
    if (sound && playbackStatus?.positionMillis) {
      let newPosition = playbackStatus.positionMillis - 5000;
      if (newPosition < 0) newPosition = 0;
      await sound.setPositionAsync(newPosition);
    }
  };

  const forwardAudio = async () => {
    if (sound && playbackStatus?.durationMillis) {
      let newPosition = playbackStatus.positionMillis + 5000;
      if (newPosition > playbackStatus.durationMillis)
        newPosition = playbackStatus.durationMillis;
      await sound.setPositionAsync(newPosition);
    }
  };

  const toggleLoop = async () => {
    setIsLooping((prev) => !prev);
    if (sound) await sound.setIsLoopingAsync(!isLooping);
  };

  const deleteAudio = () => {
    setRecordedAudio(null);
    setMenuVisible(false);
  };

  const renameAudio = () => {
    if (newAudioName.trim() === '') {
      Alert.alert('Error', 'El nombre no puede estar vacío');
      return;
    }
    setRecordedAudio({ ...recordedAudio, name: newAudioName });
    setMenuVisible(false);
    setNewAudioName('');
  };

  // FUNCIÓN DE TRANSCRIPCIÓN: Se utiliza la API de OpenAI (modelo "whisper-1")
  const transcribeAudio = async () => {
    if (!recordedAudio?.uri) {
      Alert.alert("Error", "No hay audio grabado para transcribir.");
      return;
    }
    try {
      const formData = new FormData();
      // Se adjunta el archivo de audio; asegúrate de que sea uno de los formatos soportados (mp3, m4a, wav, etc.)
      formData.append("file", {
        uri: recordedAudio.uri,
        name: "audio.mp3", // Ajusta la extensión según el formato real
        type: "audio/mpeg", // O el MIME type correspondiente
      });
      formData.append("model", "whisper-1");
      // Opcional: se puede agregar response_format para obtener el texto directamente
      formData.append("response_format", "text");

      // Realizamos la petición POST; no se incluye el header Content-Type para que fetch lo maneje
      const response = await fetch("https://api.openai.com/v1/audio/transcriptions", {
        method: "POST",
        headers: {
          "Authorization": "Bearer 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",
        },
        body: formData,
      });

      const result = await response.json();
      console.log("Respuesta de la API:", result);
      if (result.text) {
        Alert.alert("Transcripción", result.text);
      } else {
        const errorMessage = result.error?.message || "No se pudo obtener la transcripción.";
        Alert.alert("Error", errorMessage);
      }
    } catch (error) {
      Alert.alert("Error", error.message);
    }
  };

  return (
    <View style={styles.audioContainer}>
      <Text style={styles.audioTitle}>Audio</Text>
      <Animated.View style={[styles.audioCard, { opacity: pulse }]}>
        <TouchableOpacity
          style={styles.recordButton}
          onPress={isRecording ? stopRecording : startRecording}
          activeOpacity={0.7}
        >
          <Animated.View style={[styles.recordCircle, { transform: [{ scale: isRecording ? pulse : 1 }] }]} />
          <Text style={styles.recordButtonText}>
            {isRecording ? 'Detener' : 'Grabar'}
          </Text>
        </TouchableOpacity>
        {recordedAudio && (
          <>
            <View style={styles.audioInfo}>
              <Text style={styles.audioName}>{recordedAudio.name}</Text>
              <TouchableOpacity onPress={() => setMenuVisible(true)}>
                <Ionicons name="ellipsis-vertical" size={24} color="#666" />
              </TouchableOpacity>
            </View>
            <View style={styles.playbackButtons}>
              <TouchableOpacity style={styles.controlButton} onPress={rewindAudio}>
                <Ionicons name="play-skip-back" size={24} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlButton} onPress={playAudio}>
                <Ionicons name="play" size={24} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlButton} onPress={pauseAudio}>
                <Ionicons name="pause" size={24} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlButton} onPress={forwardAudio}>
                <Ionicons name="play-skip-forward" size={24} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlButton} onPress={toggleLoop}>
                <Ionicons name={isLooping ? "repeat" : "repeat-outline"} size={24} color="#fff" />
              </TouchableOpacity>
              {/* Botón para transcribir el audio */}
              <TouchableOpacity style={styles.controlButton} onPress={transcribeAudio}>
                <Ionicons name="document-text" size={24} color="#fff" />
              </TouchableOpacity>
            </View>
            <View style={styles.volumeContainer}>
              <Ionicons name="volume-high" size={24} color="#333" />
              <VolumeControl volume={volume} onChange={setVolume} />
            </View>
          </>
        )}
      </Animated.View>
      <Modal
        visible={menuVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setMenuVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.optionsModal}>
            <Text style={styles.modalTitle}>Opciones de Audio</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Nuevo nombre..."
              placeholderTextColor="#aaa"
              value={newAudioName}
              onChangeText={setNewAudioName}
            />
            <View style={styles.optionsRow}>
              <TouchableOpacity style={styles.optionButton} onPress={renameAudio}>
                <Text style={styles.optionButtonText}>Renombrar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.optionButton} onPress={deleteAudio}>
                <Text style={styles.optionButtonText}>Eliminar</Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.optionButtonSecondary} onPress={() => setMenuVisible(false)}>
              <Text style={styles.optionButtonSecondaryText}>Cerrar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

/* ===============================
   PANTALLA DE CÁMARA CON GALERÍA A PANTALLA COMPLETA
================================= */
function CameraScreen() {
  const [hasCameraPermission, setHasCameraPermission] = useState(null);
  const [hasMediaPermission, setHasMediaPermission] = useState(null);
  const [cameraRef, setCameraRef] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [mediaData, setMediaData] = useState(null);
  const [previewVisible, setPreviewVisible] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [newMediaName, setNewMediaName] = useState('');
  const [flashMode, setFlashMode] = useState(Camera.Constants.FlashMode.off);
  const [cameraType, setCameraType] = useState(Camera.Constants.Type.back);
  const [galleryVisible, setGalleryVisible] = useState(false);
  const [galleryAssets, setGalleryAssets] = useState([]);
  const [zoom, setZoom] = useState(0);
  const zoomAnim = useRef(new Animated.Value(zoom)).current;
  useEffect(() => {
    const id = zoomAnim.addListener(({ value }) => {
      setZoom(value);
    });
    return () => zoomAnim.removeListener(id);
  }, [zoomAnim]);
  const zoomOptions = [1, 3, 5, 10];
  const [proSettingsVisible, setProSettingsVisible] = useState(false);
  const [exposure, setExposure] = useState(0);
  const [brightness, setBrightness] = useState(1);
  // Estado para almacenar el contenido del QR escaneado
  const [scannedQR, setScannedQR] = useState(null);
  const galleryAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(galleryAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
      easing: Easing.out(Easing.exp),
    }).start();
  }, [galleryAnim]);
  const pressStart = useRef(0);
  const timeoutRef = useRef(null);
  const isFocused = useIsFocused();
  useEffect(() => {
    (async () => {
      const camStatus = await Camera.requestCameraPermissionsAsync();
      setHasCameraPermission(camStatus.status === 'granted');
      const mediaStatus = await MediaLibrary.requestPermissionsAsync();
      setHasMediaPermission(mediaStatus.status === 'granted');
    })();
  }, []);
  // Función para manejar el escaneo de QR
  const handleBarCodeScanned = ({ type, data }) => {
    if (data && type === QR_TYPE) {
      setScannedQR(data);
      setTimeout(() => setScannedQR(null), 5000);
    }
  };
  const toggleFlash = () => {
    setFlashMode((prev) =>
      prev === Camera.Constants.FlashMode.off ? Camera.Constants.FlashMode.on : Camera.Constants.FlashMode.off
    );
  };
  const toggleCamera = () => {
    setCameraType((prev) =>
      prev === Camera.Constants.Type.back ? Camera.Constants.Type.front : Camera.Constants.Type.back
    );
  };
  const handlePressIn = () => {
    pressStart.current = Date.now();
    timeoutRef.current = setTimeout(async () => {
      if (cameraRef && !isRecording) {
        try {
          setIsRecording(true);
          const data = await cameraRef.recordAsync();
          setMediaData({ type: 'video', uri: data.uri, name: 'Video capturado' });
          setIsRecording(false);
          setPreviewVisible(true);
          if (hasMediaPermission) {
            await MediaLibrary.saveToLibraryAsync(data.uri);
          }
        } catch (error) {
          console.error('Error grabando video:', error);
        }
      }
    }, 500);
  };
  const handlePressOut = async () => {
    clearTimeout(timeoutRef.current);
    const duration = Date.now() - pressStart.current;
    if (duration < 500 && cameraRef && !isRecording) {
      try {
        const photo = await cameraRef.takePictureAsync();
        setMediaData({ type: 'photo', uri: photo.uri, name: 'Foto capturada' });
        if (hasMediaPermission) {
          await MediaLibrary.saveToLibraryAsync(photo.uri);
        }
        setPreviewVisible(true);
      } catch (error) {
        console.error('Error al tomar foto:', error);
      }
    } else if (isRecording && cameraRef) {
      try {
        await cameraRef.stopRecording();
        setIsRecording(false);
      } catch (error) {
        console.error('Error al detener video:', error);
      }
    }
  };
  const closePreview = () => {
    setPreviewVisible(false);
    setMediaData(null);
  };
  const deleteMedia = () => {
    setMediaData(null);
    setMenuVisible(false);
    setPreviewVisible(false);
  };
  const renameMedia = () => {
    if (newMediaName.trim() === '') {
      Alert.alert('Error', 'El nombre no puede estar vacío');
      return;
    }
    setMediaData({ ...mediaData, name: newMediaName });
    setMenuVisible(false);
    setNewMediaName('');
  };
  const loadGallery = async () => {
    if (hasMediaPermission) {
      const assets = await MediaLibrary.getAssetsAsync({
        first: 20,
        mediaType: ['photo', 'video'],
      });
      setGalleryAssets(assets.assets);
    }
  };
  if (hasCameraPermission === null) {
    return (
      <View style={styles.centered}>
        <Text style={styles.infoText}>Solicitando permisos...</Text>
      </View>
    );
  }
  if (hasCameraPermission === false) {
    return (
      <View style={styles.centered}>
        <Text style={styles.infoText}>No se tiene acceso a la cámara</Text>
      </View>
    );
  }
  return (
    <View style={styles.cameraContainer}>
      {isFocused && (
        <Camera
          style={StyleSheet.absoluteFill}
          type={cameraType}
          flashMode={flashMode}
          zoom={zoom}
          ref={(ref) => setCameraRef(ref)}
          onBarCodeScanned={scannedQR ? undefined : handleBarCodeScanned}
          barcodeScannerSettings={{ barcodeTypes: [QR_TYPE] }}
        >
          {scannedQR && (
            <View style={styles.qrBubble}>
              <Text style={styles.qrText}>{scannedQR}</Text>
            </View>
          )}
          <View style={styles.cameraTopControls}>
            <TouchableOpacity style={styles.iconButton} onPress={toggleFlash}>
              <Ionicons name={flashMode === Camera.Constants.FlashMode.off ? 'flash-off' : 'flash'} size={28} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.proButton} onPress={() => setProSettingsVisible((prev) => !prev)}>
              <Ionicons name="aperture" size={28} color="#fff" />
              <Text style={styles.proButtonText}>PRO</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconButton} onPress={toggleCamera}>
              <Ionicons name="camera-reverse" size={28} color="#fff" />
            </TouchableOpacity>
          </View>
          <View style={styles.zoomContainer}>
            {zoomOptions.map((factor) => {
              const targetZoom = (factor - 1) / 9;
              const selected = Math.abs(zoom - targetZoom) < 0.01;
              return (
                <TouchableOpacity
                  key={factor}
                  style={[styles.zoomBubble, selected && styles.zoomBubbleSelected]}
                  onPress={() => {
                    Animated.timing(zoomAnim, {
                      toValue: targetZoom,
                      duration: 300,
                      useNativeDriver: false,
                    }).start();
                  }}
                >
                  <Text style={selected ? styles.zoomBubbleTextSelected : styles.zoomBubbleText}>{`x${factor}`}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
          <View style={styles.cameraBottomControls}>
            <TouchableOpacity
              style={[styles.captureButton, isRecording && styles.captureButtonRecording]}
              onPressIn={handlePressIn}
              onPressOut={handlePressOut}
            >
              <View style={styles.innerCaptureButton} />
            </TouchableOpacity>
          </View>
        </Camera>
      )}
      {mediaData && (
        <TouchableOpacity style={styles.thumbnailContainer} onPress={() => setPreviewVisible(true)}>
          <Image source={{ uri: mediaData.uri }} style={styles.thumbnail} />
        </TouchableOpacity>
      )}
      <TouchableOpacity
        style={styles.galleryButtonAbsolute}
        onPress={async () => {
          await loadGallery();
          setGalleryVisible(true);
        }}
      >
        <Ionicons name="images" size={30} color="#fff" />
      </TouchableOpacity>
      <Modal
        visible={proSettingsVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setProSettingsVisible(false)}
      >
        <View style={styles.proModalOverlay}>
          <View style={styles.proModal}>
            <Text style={styles.proModalTitle}>Ajustes PRO</Text>
            <Text style={styles.proLabel}>Exposición</Text>
            <View style={styles.proBubbleContainer}>
              {[-2, -1, 0, 1, 2].map((val) => {
                const selected = exposure === val;
                return (
                  <TouchableOpacity key={`exposure-${val}`} style={[styles.proBubble, selected && styles.proBubbleSelected]} onPress={() => setExposure(val)}>
                    <Text style={selected ? styles.proBubbleTextSelected : styles.proBubbleText}>{val}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            <Text style={styles.proLabel}>Brillo</Text>
            <View style={styles.proBubbleContainer}>
              {[0.5, 1, 1.5, 2].map((val) => {
                const selected = brightness === val;
                return (
                  <TouchableOpacity key={`brightness-${val}`} style={[styles.proBubble, selected && styles.proBubbleSelected]} onPress={() => setBrightness(val)}>
                    <Text style={selected ? styles.proBubbleTextSelected : styles.proBubbleText}>{val}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            <TouchableOpacity style={styles.proCloseButton} onPress={() => setProSettingsVisible(false)}>
              <Text style={styles.proCloseButtonText}>Cerrar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      <Modal visible={previewVisible} transparent={false} animationType="slide" onRequestClose={closePreview}>
        <View style={styles.fullScreenPreview}>
          {mediaData ? (
            mediaData.type === 'photo' ? (
              <Image source={{ uri: mediaData.uri }} style={styles.fullPreviewMedia} resizeMode="contain" />
            ) : (
              <Video source={{ uri: mediaData.uri }} style={styles.fullPreviewMedia} useNativeControls resizeMode="contain" />
            )
          ) : (
            <Text style={{ color: '#fff' }}>No hay media</Text>
          )}
          <TouchableOpacity style={styles.fullCloseButton} onPress={closePreview}>
            <Text style={styles.fullCloseText}>Cerrar</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.fullMenuButton} onPress={() => setMenuVisible(true)}>
            <Text style={styles.fullMenuText}>⋮</Text>
          </TouchableOpacity>
        </View>
        <Modal visible={menuVisible} transparent={true} animationType="fade" onRequestClose={() => setMenuVisible(false)}>
          <View style={styles.modalOverlay}>
            <View style={styles.optionsModal}>
              <Text style={styles.modalTitle}>Opciones del Archivo</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Nuevo nombre..."
                placeholderTextColor="#aaa"
                value={newMediaName}
                onChangeText={setNewMediaName}
              />
              <View style={styles.optionsRow}>
                <TouchableOpacity style={styles.optionButton} onPress={renameMedia}>
                  <Text style={styles.optionButtonText}>Renombrar</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.optionButton} onPress={deleteMedia}>
                  <Text style={styles.optionButtonText}>Eliminar</Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity style={styles.optionButtonSecondary} onPress={() => setMenuVisible(false)}>
                <Text style={styles.optionButtonSecondaryText}>Cerrar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </Modal>
      <Modal visible={galleryVisible} transparent={false} animationType="slide" onRequestClose={() => setGalleryVisible(false)}>
        <View style={styles.galleryModal}>
          <Text style={styles.galleryTitle}>Galería</Text>
          <FlatList
            data={galleryAssets}
            keyExtractor={(item) => item.id}
            numColumns={3}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.galleryItem}
                onPress={() => {
                  setMediaData({
                    type: item.mediaType === 'photo' ? 'photo' : 'video',
                    uri: item.uri,
                    name: 'Elemento de Galería',
                  });
                  setGalleryVisible(false);
                  setPreviewVisible(true);
                }}
              >
                <Image source={{ uri: item.uri }} style={styles.galleryImage} />
              </TouchableOpacity>
            )}
          />
          <TouchableOpacity style={styles.galleryCloseButton} onPress={() => setGalleryVisible(false)}>
            <Text style={styles.galleryCloseText}>Cerrar Galería</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
}

/* ==============================================
   NAVEGACIÓN CON TRANSICIONES FLUIDAS
============================================= */
export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        initialRouteName="Camera"
        lazy={true}
        tabBarPosition="bottom"
        screenOptions={{
          swipeEnabled: true,
          animationEnabled: true,
          tabBarShowLabel: false,
          tabBarStyle: {
            backgroundColor: 'transparent',
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            elevation: 0,
          },
        }}
        tabBar={(props) => <MyTabBar {...props} />}
      >
        <Tab.Screen name="Audio" component={AudioScreen} />
        <Tab.Screen name="Camera" component={CameraScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

/* ==============================================
   ESTILOS
============================================= */
const PRIMARY_COLOR = '#1E88E5';
const SECONDARY_COLOR = '#D32F2F';
const DARK_BG = '#000000';
const WHITE = '#ffffff';
const GRAY = '#888888';

const styles = StyleSheet.create({
  /* ----- AUDIO SCREEN ----- */
  audioContainer: {
    flex: 1,
    backgroundColor: '#f3f3f3',
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  audioTitle: {
    fontSize: 26,
    fontWeight: '600',
    color: PRIMARY_COLOR,
    marginBottom: 10,
  },
  audioCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    elevation: 4,
  },
  recordButton: {
    alignItems: 'center',
    marginBottom: 20,
  },
  recordCircle: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: SECONDARY_COLOR,
    marginBottom: 8,
  },
  recordButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  audioInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  audioName: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    marginRight: 8,
  },
  playbackButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 10,
  },
  controlButton: {
    backgroundColor: PRIMARY_COLOR,
    borderRadius: 20,
    padding: 10,
    marginHorizontal: 4,
  },
  volumeContainer: {
    marginTop: 10,
    alignItems: 'center',
  },
  volumeControlContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '90%',
  },
  volumeBar: {
    flex: 1,
    height: 20,
    marginHorizontal: 4,
    borderRadius: 4,
  },

  /* ----- MODAL GENÉRICO ----- */
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  optionsModal: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    width: '80%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    color: '#333',
    fontWeight: '600',
    marginBottom: 10,
  },
  modalInput: {
    width: '100%',
    backgroundColor: '#eee',
    color: '#000',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginBottom: 15,
  },
  optionsRow: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  optionButton: {
    backgroundColor: PRIMARY_COLOR,
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginHorizontal: 5,
  },
  optionButtonText: {
    color: WHITE,
    fontWeight: '600',
  },
  optionButtonSecondary: {
    backgroundColor: '#ccc',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  optionButtonSecondaryText: {
    color: '#333',
    fontWeight: '600',
  },

  /* ----- CÁMARA ----- */
  cameraContainer: {
    flex: 1,
    backgroundColor: DARK_BG,
  },
  cameraTopControls: {
    position: 'absolute',
    top: 40,
    left: 20,
    flexDirection: 'row',
    zIndex: 10,
    alignItems: 'center',
  },
  iconButton: {
    marginRight: 15,
  },
  proButton: {
    marginRight: 15,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 8,
  },
  proButtonText: {
    color: '#fff',
    fontSize: 10,
    marginTop: 2,
  },
  cameraBottomControls: {
    position: 'absolute',
    bottom: 80,
    width: '100%',
    alignItems: 'center',
    zIndex: 10,
  },
  captureButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    borderWidth: 4,
    borderColor: WHITE,
    justifyContent: 'center',
    alignItems: 'center',
  },
  captureButtonRecording: {
    borderColor: SECONDARY_COLOR,
  },
  innerCaptureButton: {
    width: 45,
    height: 45,
    borderRadius: 22.5,
    backgroundColor: PRIMARY_COLOR,
  },
  thumbnailContainer: {
    position: 'absolute',
    bottom: 80,
    left: 20,
    borderWidth: 2,
    borderColor: PRIMARY_COLOR,
    borderRadius: 50,
    width: 60,
    height: 60,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.5)',
    zIndex: 10,
  },
  thumbnail: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },

  /* ----- Selector de Zoom ----- */
  zoomContainer: {
    position: 'absolute',
    bottom: 160,
    alignSelf: 'center',
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: 20,
    padding: 8,
  },
  zoomBubble: {
    backgroundColor: '#444',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginHorizontal: 5,
  },
  zoomBubbleSelected: {
    backgroundColor: PRIMARY_COLOR,
  },
  zoomBubbleText: {
    color: '#fff',
    fontWeight: '600',
  },
  zoomBubbleTextSelected: {
    color: '#fff',
    fontWeight: '700',
  },

  /* ----- Botón de Galería ----- */
  galleryButtonAbsolute: {
    position: 'absolute',
    bottom: 80,
    right: 20,
    backgroundColor: PRIMARY_COLOR,
    padding: 10,
    borderRadius: 30,
    zIndex: 10,
  },

  /* ----- PRO SETTINGS MODAL ----- */
  proModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  proModal: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    width: '80%',
    alignItems: 'center',
  },
  proModalTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
    color: '#333',
  },
  proLabel: {
    fontSize: 14,
    color: '#333',
    marginTop: 10,
  },
  proBubbleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginVertical: 10,
  },
  proBubble: {
    backgroundColor: '#eee',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  proBubbleSelected: {
    backgroundColor: PRIMARY_COLOR,
  },
  proBubbleText: {
    color: '#333',
    fontWeight: '600',
  },
  proBubbleTextSelected: {
    color: WHITE,
    fontWeight: '700',
  },
  proCloseButton: {
    backgroundColor: PRIMARY_COLOR,
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginTop: 10,
  },
  proCloseButtonText: {
    color: WHITE,
    fontWeight: '600',
  },

  /* ----- PREVIEW FULL SCREEN ----- */
  fullScreenPreview: {
    flex: 1,
    backgroundColor: DARK_BG,
    justifyContent: 'center',
    alignItems: 'center',
  },
  fullPreviewMedia: {
    width: '100%',
    height: '100%',
  },
  fullCloseButton: {
    position: 'absolute',
    top: 40,
    left: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  fullCloseText: {
    color: WHITE,
    fontSize: 16,
    fontWeight: '600',
  },
  fullMenuButton: {
    position: 'absolute',
    bottom: 40,
    right: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 20,
    padding: 10,
  },
  fullMenuText: {
    color: WHITE,
    fontSize: 24,
  },

  /* ----- GALERÍA ----- */
  galleryModal: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 40,
    paddingHorizontal: 10,
  },
  galleryTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: PRIMARY_COLOR,
    textAlign: 'center',
    marginBottom: 10,
  },
  galleryItem: {
    flex: 1 / 3,
    margin: 5,
  },
  galleryImage: {
    width: '100%',
    height: 100,
    borderRadius: 8,
  },
  galleryCloseButton: {
    backgroundColor: PRIMARY_COLOR,
    borderRadius: 20,
    padding: 10,
    marginVertical: 10,
    alignSelf: 'center',
  },
  galleryCloseText: {
    color: WHITE,
    fontWeight: '600',
  },

  /* ----- CUSTOM TAB BAR ----- */
  customTabBar: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.5)',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 60,
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  tabBarItem: {
    flex: 1,
    alignItems: 'center',
  },

  /* ----- BURBUJA DEL QR ----- */
  qrBubble: {
    position: 'absolute',
    top: 100,
    alignSelf: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)',
    padding: 10,
    borderRadius: 10,
    zIndex: 20,
  },
  qrText: {
    color: WHITE,
    fontSize: 14,
  },

  /* ----- CENTRADO ----- */
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoText: {
    fontSize: 16,
    color: '#333',
  },
});

